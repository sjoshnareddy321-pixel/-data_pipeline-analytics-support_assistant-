from fastapi import FastAPI
from pydantic import BaseModel, Field
from rag_service import AssistantResponse, ask, build_vector_store

app = FastAPI(title="Zepto Support Assistant")

class AskRequest(BaseModel):
    query: str = Field(min_length=1)

@app.on_event("startup")
def startup():
    build_vector_store()

@app.post("/ask", response_model=AssistantResponse)
def ask_endpoint(request: AskRequest):
    return ask(request.query)
