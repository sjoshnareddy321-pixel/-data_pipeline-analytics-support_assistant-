from __future__ import annotations
import os
from pathlib import Path
from typing import TypedDict
import chromadb
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer
from langgraph.graph import END, START, StateGraph
from prompt_template import PROMPT_TEMPLATE

BASE = Path(__file__).parent
DOCS = BASE / "docs"
CHROMA_PATH = BASE / "chroma_db"
COLLECTION_NAME = "zepto_policies"
KEYWORDS = ("delivery","return","refund","membership","tracking","cancel","gift card","support hours")

class AssistantResponse(BaseModel):
    answer: str
    sources: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)

class AssistantState(TypedDict, total=False):
    query: str
    intent: str
    retrieved: list[dict]
    answer: str
    sources: list[str]
    confidence: float

class LocalEmbedder:
    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
    def encode(self, texts):
        return self.model.encode(texts, normalize_embeddings=True).tolist()

def build_vector_store():
    embedder = LocalEmbedder()
    client = chromadb.PersistentClient(path=str(CHROMA_PATH))
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    collection = client.create_collection(
        name=COLLECTION_NAME, metadata={"hnsw:space": "cosine"}
    )
    ids, texts, metadatas = [], [], []
    for path in sorted(DOCS.glob("doc_*.txt")):
        ids.append(path.stem)
        texts.append(path.read_text(encoding="utf-8").strip())
        metadatas.append({"source": path.name})
    collection.add(ids=ids, documents=texts, embeddings=embedder.encode(texts), metadatas=metadatas)
    return collection

def get_collection():
    return chromadb.PersistentClient(path=str(CHROMA_PATH)).get_collection(COLLECTION_NAME)

def retrieve(query: str, top_k: int = 3):
    embedding = LocalEmbedder().encode([query])[0]
    result = get_collection().query(
        query_embeddings=[embedding], n_results=top_k,
        include=["documents","metadatas","distances"]
    )
    return [
        {"id": result["ids"][0][i], "document": result["documents"][0][i],
         "source": result["metadatas"][0][i]["source"], "distance": result["distances"][0][i]}
        for i in range(len(result["ids"][0]))
    ]

def classify_intent(state: AssistantState):
    q = state["query"].lower()
    return {"intent": "policy_question" if any(k in q for k in KEYWORDS) else "general_question"}

def retrieve_and_answer(state: AssistantState):
    retrieved = retrieve(state["query"], 3)
    snippet = retrieved[0]["document"][:200].strip() if retrieved else ""
    if os.getenv("MOCK_LLM", "1") != "0":
        r = AssistantResponse(
            answer=f"Based on the retrieved context: {snippet}",
            sources=[x["id"] for x in retrieved], confidence=1.0
        )
        return {"retrieved": retrieved, "answer": r.answer, "sources": r.sources, "confidence": r.confidence}
    r = real_llm_with_retry(state["query"], retrieved)
    return {"retrieved": retrieved, "answer": r.answer, "sources": r.sources, "confidence": r.confidence}

def direct_answer(state: AssistantState):
    if os.getenv("MOCK_LLM", "1") != "0":
        r = AssistantResponse(
            answer="I can only answer questions about Zepto policies right now.",
            sources=[], confidence=1.0
        )
        return {"answer": r.answer, "sources": [], "confidence": 1.0}
    r = real_llm_with_retry(state["query"], [])
    return {"answer": r.answer, "sources": r.sources, "confidence": r.confidence}

def validate_real_output(raw):
    return AssistantResponse.model_validate_json(raw)

def real_llm_with_retry(query, retrieved):
    try:
        from groq import Groq
    except ImportError as e:
        raise RuntimeError("MOCK_LLM=0 requires the optional groq package and GROQ_API_KEY.") from e
    context = "\n\n".join(f"[{x['id']}] {x['document']}" for x in retrieved)
    prompt = PROMPT_TEMPLATE.format(context=context, query=query)
    client = Groq(api_key=os.environ["GROQ_API_KEY"])
    messages = [{"role":"user","content":prompt}]
    last_error = None
    for attempt in range(3):
        if attempt:
            messages.append({"role":"user","content":
                "Corrective instruction: return only valid JSON matching the answer/sources/confidence schema. Do not add markdown."})
        raw = client.chat.completions.create(
            model=os.getenv("GROQ_MODEL","llama-3.1-8b-instant"),
            messages=messages, temperature=0
        ).choices[0].message.content
        try:
            return validate_real_output(raw)
        except Exception as e:
            last_error = e
    return AssistantResponse(
        answer=f"ERROR: LLM output failed schema validation after 3 attempts: {last_error}",
        sources=[], confidence=0.0
    )

def route(state):
    return "retrieve_and_answer" if state["intent"] == "policy_question" else "direct_answer"

def build_graph():
    g = StateGraph(AssistantState)
    g.add_node("classify_intent", classify_intent)
    g.add_node("retrieve_and_answer", retrieve_and_answer)
    g.add_node("direct_answer", direct_answer)
    g.add_edge(START, "classify_intent")
    g.add_conditional_edges("classify_intent", route, {
        "retrieve_and_answer":"retrieve_and_answer", "direct_answer":"direct_answer"
    })
    g.add_edge("retrieve_and_answer", END)
    g.add_edge("direct_answer", END)
    return g.compile()

def ask(query: str):
    s = build_graph().invoke({"query": query})
    return AssistantResponse(
        answer=s["answer"], sources=s.get("sources", []), confidence=s.get("confidence", 0.0)
    )
