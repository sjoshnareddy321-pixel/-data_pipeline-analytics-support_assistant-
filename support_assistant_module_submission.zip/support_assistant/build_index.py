from rag_service import build_vector_store
if __name__ == "__main__":
    c = build_vector_store()
    print("Chroma collection:", c.name)
    print("Indexed documents:", c.count())
