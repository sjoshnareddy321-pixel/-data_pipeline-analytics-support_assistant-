import os
os.environ.setdefault("MOCK_LLM", "1")
from build_index import build_vector_store
from rag_service import ask
if __name__ == "__main__":
    c = build_vector_store()
    assert c.count() == 8
    policy = ask("How much is priority delivery?")
    general = ask("What is the capital of France?")
    print("POLICY RESPONSE:")
    print(policy.model_dump_json())
    print("\nGENERAL RESPONSE:")
    print(general.model_dump_json())
    assert policy.sources
    assert "Based on the retrieved context:" in policy.answer
    assert general.sources == []
    assert general.answer == "I can only answer questions about Zepto policies right now."
